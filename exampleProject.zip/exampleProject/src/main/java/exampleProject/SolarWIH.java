package exampleProject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.drools.core.process.instance.WorkItemHandler;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;

public class SolarWIH implements WorkItemHandler {
	
	
	
	public void abortWorkItem(WorkItem wi, WorkItemManager wim) {
		System.out.println("Oh no, my item aborted..");

	}

	public void executeWorkItem(WorkItem wi, WorkItemManager wim) {
		 
		
		System.out.println("Inside Custom WorkItemHandler ExecuteWorkItem");
		//TODO READ PARAMS
		int param1 = (Integer) wi.getParameter("powerUsage");
		//String param2 = wi.getParameter("Param2").toString();
		//String param3 = wi.getParameter("Param3").toString();
		
		
		//TODO EXECUTE BUSINESS LOGIC
		System.out.println("powerUsage:"+param1);
		//System.out.println("param2:"+param2);
		//System.out.println("param3:"+param3);
				
		//TODO PASS RESULTS
		Map<String,Object> results=new HashMap<String,Object>();
		if(param1 < 10000) {
		results.put("electricalPermitStatus", "Approved");
		}
		else
		{
		results.put("electricalPermitStatus", "Denied");
		}
		
		//throwing an exception
	
		
		//safe practice to write it before
		
		
			
     	wim.completeWorkItem(wi.getId(), results);
	}
	
	

}