package com.citi.tcs;

public class UserPermissions {
	
	 private String structuralPermit;
	 private String electricalPermit;
	public String getStructuralPermit() {
		return structuralPermit;
	}
	public void setStructuralPermit(String structuralPermit) {
		this.structuralPermit = structuralPermit;
	}
	public String getElectricalPermit() {
		return electricalPermit;
	}
	public void setElectricalPermit(String electricalPermit) {
		this.electricalPermit = electricalPermit;
	}
	 

}
