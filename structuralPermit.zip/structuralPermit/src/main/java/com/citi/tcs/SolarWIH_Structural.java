package com.citi.tcs;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.drools.core.process.instance.WorkItemHandler;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;

public class SolarWIH_Structural implements WorkItemHandler {
	
	
	
	public void abortWorkItem(WorkItem wi, WorkItemManager wim) {
		System.out.println("Oh no, my approval aborted..");

	}

	public void executeWorkItem(WorkItem wi, WorkItemManager wim) {
		 
		
		System.out.println("Inside Custom WorkItemHandler ExecuteWorkItem");
		//TODO READ PARAMS
		int param1 = (Integer) wi.getParameter("homeDimensions");

		//String param3 = wi.getParameter("Param3").toString();
		
		
		//TODO EXECUTE BUSINESS LOGIC
		System.out.println("HomeDimensions:"+param1);
		//System.out.println("param2:"+param2);
	//	System.out.println("param3:"+param3);
				
		//TODO PASS RESULTS
		Map<String,Object> results=new HashMap<String,Object>();
		 
		if(param1 < 10000) {
			
		results.put("structuralPermitStatus", "Approved");
		}
		else
		{
		results.put("structuralPermitStatus", "Denied");
		}
		
		//throwing an exception
	
		
		//safe practice to write it before
		
		
			
     	wim.completeWorkItem(wi.getId(), results);
	}
	
	

}